# Tourays Fitness V8 — Build 5.1

## Important animation correction

The previous Build 5 still rendered a code-generated SVG figure, so the visual improvement was not convincing enough.

This hotfix now includes:
- A visibly different image-based push-up demonstration
- Premium athletic artwork
- Real upper and lower push-up positions
- A 10-second looping GIF
- Movement direction cue
- Progress bar
- Replay support
- The existing SVG engine remains only as a fallback for the other exercises

The push-up is the first proof-of-concept animation. Each other exercise still requires its own premium source artwork to reach the same standard.
