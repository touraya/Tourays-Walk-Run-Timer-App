# Tourays Fitness V8 — Build 4

## Walk & Run Premium Redesign

- New workout preview card
- Live cycle duration calculation
- Estimated cycle count
- Walk-versus-run timeline
- Run-share percentage
- Easy, Steady and Strong intensity choices
- Dynamic workout title and start-button summary
- Clear GPS readiness card
- Brighter preset cards
- Improved custom interval controls
- Refined active workout cards and controls
- All previous Version 8 and Version 7 functionality remains included

Replace all files in the existing deployment with the files from this ZIP.
